import React, { Suspense } from "react";
/*import { AiFillEdit, AiFillRest } from "react-icons/ai";*/
import { NavLink, useLoaderData, Await, useParams } from "react-router-dom";
import ApiFetch from "../util/ApiFetch";
import Button from "../util/Button";
/*import styles from "../css/Styles.module.css";*/

export const loader = ({ params: { id } }) => {
  const notePromise = ApiFetch.getNote(id);
  return { notePromise };
};

export default function ViewNote() {
  const { id } = useParams();
  const { notePromise } = useLoaderData();
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <Await
        resolve={notePromise}
        errorElement={<div>404: There is no such note.</div>}
      >
        {(note) => {
          return (
            <div>
              <div className="block my-8 md:flex md:justify-center md:gap-12 md:items-center"/*className={`${styles.titlePage}`}*/>
                <Button $to="/notes" $text="Back"></Button>
                <p className="text-3xl font-bold break-all mt-4">
                  {note.title}
                </p>
                <div className="flex gap-4 mt-4 justify-center md:justify-normal"/*{`${styles.viewBtn}`}*/>
                  <NavLink to={`/notes/edit/${id}`}>
                    <AiFillEdit className=" w-6 h-6" />
                  </NavLink>
                  <NavLink
                    to={"/notes"}
                    reloadDocument="true"
                    onClick={() => {
                      ApiFetch.deleteNote(note.id);
                    }}
                  >
                    <AiFillRest className="w-6 h-6" />
                  </NavLink>
                </div>
              </div>
              <div className="p-10 min-h-max max-h-max text-left bg-slate-300">
                <p className="h-auto break-words">{note.text}</p>
              </div>
            </div>
          );
        }}
      </Await>
    </Suspense>
  );
}